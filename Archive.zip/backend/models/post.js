const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the item schema
const itemSchema = new Schema({
    name: { type: String, required: true },
    phone: [String], // Array of phone numbers
    address: String,
    specialization: String,
    website: [String], // Array of website URLs
    priority: { type: Number, default: 5 } // Default priority value
});

// Define the Post schema
const PostSchema = new Schema({
  cat_id: { type: Number, required: true }, // Changed to Number for consistent API data
  cat: { type: String, required: true },
  data: [itemSchema], // Array of items

  createdAt: { type: Date, default: Date.now },
});

// Export the Post model
module.exports = mongoose.model('Post', PostSchema);
