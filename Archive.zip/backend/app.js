const dotenv = require('dotenv');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');

// Load environment variables from .env file
dotenv.config();

const authenticate = require('./middlewares/authenticate');
const ratingRoutes = require('./routes/rating');
const loginRoutes = require('./routes/login');
const postsRouter = require('./routes/post');

const app = express();
const PORT = process.env.PORT || 5000;

const corsOptions = {
  origin: ['https://www.sector7xnoida.com','http://localhost:3000'],
  credentials: true,
};

// Middleware
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('MongoDB connected');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

// Routes
app.use('/api/ratings', ratingRoutes);
app.use('/api/posts', postsRouter);
app.use('/api', loginRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
