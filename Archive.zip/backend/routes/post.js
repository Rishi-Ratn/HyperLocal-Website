const express = require('express');
const router = express.Router();
const Post = require('../models/Post'); // Ensure the correct case for 'Post'

// GET all posts
router.get('/', async (req, res, next) => {
  try {
    const posts = await Post.find().sort({ createdAt: 'desc' });
    return res.status(200).json({
      statusCode: 200,
      message: 'Fetched all posts',
      data: { posts },
    });
  } catch (err) {
    return res.status(500).json({
      statusCode: 500,
      message: 'Failed to fetch posts',
      error: err.message,
    });
  }
});

// GET a single post by ID
router.get('/:id', async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({
        statusCode: 404,
        message: 'Post not found',
        data: {},
      });
    }
    return res.status(200).json({
      statusCode: 200,
      message: 'Fetched post',
      data: { post },
    });
  } catch (err) {
    return res.status(500).json({
      statusCode: 500,
      message: 'Failed to fetch post',
      error: err.message,
    });
  }
});

// POST a new post
router.post('/', async (req, res, next) => {
  try {
    const { cat_id, cat, data, priority } = req.body;
    const post = new Post({
      cat_id,
      cat,
      data,
      priority,
    });
    await post.save();
    return res.status(201).json({
      statusCode: 201,
      message: 'Created post',
      data: { post },
    });
  } catch (err) {
    return res.status(500).json({
      statusCode: 500,
      message: 'Failed to create post',
      error: err.message,
    });
  }
});


// POST multiple posts
router.post('/multiple', async (req, res, next) => {
    try {
      const posts = req.body.posts; // Expecting an array of posts
      const insertedPosts = await Post.insertMany(posts);
      return res.status(201).json({
        statusCode: 201,
        message: 'Created multiple posts',
        data: { insertedPosts },
      });
    } catch (err) {
      return res.status(500).json({
        statusCode: 500,
        message: 'Failed to create multiple posts',
        error: err.message,
      });
    }
  });

// PUT update an existing post
router.put('/:id', async (req, res, next) => {
  try {
    const { cat_id, cat, data, priority } = req.body;
    const post = await Post.findByIdAndUpdate(
      req.params.id,
      { cat_id, cat, data, priority },
      { new: true } // Return the updated document
    );
    if (!post) {
      return res.status(404).json({
        statusCode: 404,
        message: 'Post not found',
        data: {},
      });
    }
    return res.status(200).json({
      statusCode: 200,
      message: 'Updated post',
      data: { post },
    });
  } catch (err) {
    return res.status(500).json({
      statusCode: 500,
      message: 'Failed to update post',
      error: err.message,
    });
  }
});

// DELETE a post
router.delete('/:id', async (req, res, next) => {
  try {
    const result = await Post.deleteOne({ _id: req.params.id });
    if (result.deletedCount === 0) {
      return res.status(404).json({
        statusCode: 404,
        message: 'Post not found',
        data: {},
      });
    }
    return res.status(200).json({
      statusCode: 200,
      message: `Deleted ${result.deletedCount} post(s)`,
      data: {},
    });
  } catch (err) {
    return res.status(500).json({
      statusCode: 500,
      message: 'Failed to delete post',
      error: err.message,
    });
  }
});


// const data = [you can insert your data here];  // here you can insert many data in database
  
//   Post.insertMany(data)
//     .then((docs) => {
//       console.log('Data inserted successfully:', docs);
//     })
//     .catch((err) => {
//       console.error('Error inserting data:', err);
//     });
  

module.exports = router;
