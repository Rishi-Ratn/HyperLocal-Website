const authenticate = (req, res, next) => {
    const { username, password } = req.body;
  
    if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
      return next();
    } else {
      return res.status(401).json({ error: 'Unauthorized' });
    }
  };
  
  module.exports = authenticate;
  