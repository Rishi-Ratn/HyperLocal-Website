import React, { useEffect, useState } from 'react';
import '../App.css';
import axios from 'axios';
import { useNavigate, Link, useParams } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Rating from './Rating'; // Import the Rating component

const App = () => {
  const { society } = useParams();
  const [myData, setMyData] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [isError, setIsError] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [ratings, setRatings] = useState({});
  const { user, loginWithRedirect, logout, isAuthenticated } = useAuth0();
  const navigate = useNavigate();

  useEffect(() => {
    let dataUrl = "";
    if (society === "mahaguna-moderne") {
      dataUrl = "https://raw.githubusercontent.com/ayushku634/ayushku634/main/data.json";
    } else if (society === "mahaguna-historic") {
      dataUrl = "https://raw.githubusercontent.com/ayushku634/ayushku634/main/fac.json";
    }

    axios
      .get(dataUrl)
      .then((response) => {
        setMyData(response.data);
        if (response.data.length > 0) {
          setSelectedCategory(response.data[0].cat_id.toString());
        }
        setIsLoading(false);

        const storedRatings = JSON.parse(localStorage.getItem('ratings')) || {};
        setRatings(storedRatings);
      })
      .catch((error) => {
        setIsError(error.message);
        setIsLoading(false);
      });
  }, [society]);

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value);
  };

  const handleRate = async (itemId, ratings) => {
    if (!isAuthenticated) {
      loginWithRedirect().then(() => {
      }).catch((error) => {
        toast.error('Error during login:', error);
      });
    } else {
      try {
        const response = await axios.post('http://localhost:5002/api/ratings', {
          itemId,
          ratings,
          userEmail: user.email
        });

        if (response.data.success) {
          const updatedRatings = { ...ratings };
          if (!updatedRatings[itemId]) {
            updatedRatings[itemId] = { count: 0, sum: 0, users: [] };
          }

          updatedRatings[itemId].count += 1;
          updatedRatings[itemId].sum += ratings;
          updatedRatings[itemId].users.push(user.email);

          setRatings(updatedRatings);
        }
      } catch (error) {
        toast.error('Error submitting rating:', error);
      }
    }
  };

  const getAverageRating = (itemId) => {
    const currentRatings = ratings[itemId] || { count: 0, sum: 0 };
    return currentRatings.count > 0 ? currentRatings.sum / currentRatings.count : 0;
  };

  const selectedData = myData.find(
    (category) => category.cat_id.toString() === selectedCategory
  );

  const handleLogin = async () => {
    try {
      await loginWithRedirect();
    } catch (error) {
      toast.error(error);
    }
  };

  const handleLogout = () => {
    logout({ returnTo: window.location.origin });
    toast.success('Successfully logged out');
  };

  return (
    <>
      <header>
        <div className="header-left">
          <h1>Contact Informationn</h1>
        </div>
        <div className="header-right">
          {isAuthenticated ? (
            <button onClick={handleLogout}>Logout</button>
          ) : (
            <button onClick={handleLogin}>Login</button>
          )}
          <select onChange={(e) => navigate(`/${e.target.value}`)}>
            <option value="mahaguna-moderne">Mahaguna Moderne</option>
            <option value="mahaguna-historic">Mahaguna Historic</option>
            <option value="..">Starter Page</option>
          </select>
        </div>
      </header>
      
      {isLoading ? (
        <h2>Loading...</h2>
      ) : isError ? (
        <h2>Error: {isError}</h2>
      ) : (
        <>
          <div className="content-wrapper">
            <div className="main-content">
              <div className="dropdown">
                <label htmlFor="category-select">Choose a category:</label>
                <select
                  id="category-select"
                  value={selectedCategory}
                  onChange={handleCategoryChange}
                  aria-label="Select Category"
                >
                  {myData.map((category) => (
                    <option key={category.cat_id} value={category.cat_id.toString()}>
                      {category.cat}
                    </option>
                  ))}
                </select>
              </div>

              {selectedData && (
                <>
                  <h2 className="category-heading">{selectedData.cat}</h2>
                  <div className="grid">
                    {selectedData.data.map((item, index) => (
                      <div key={index} className="card">
                        <Link to={`/item/${item.name}`} target='_blank'>
                          <h3>{item.name}</h3>
                        </Link>
                        {Array.isArray(item.phone) ? (
                          <p>
                            <span role="img" aria-label="phone">📞</span> +91{" "}
                            {item.phone.map((phone, i) => (
                              <a key={i} href={`tel:${phone}`}>
                                {phone}
                              </a>
                            )).reduce((prev, curr) => [prev, ', ', curr])}
                          </p>
                        ) : (
                          <p><span role="img" aria-label="phone">📞</span> <a href={`tel:${item.phone}`}>+91 {item.phone}</a></p>
                        )}
                        {item.address && <p>Address: {item.address}</p>}
                        {item.specialization && <p>Specialization: {item.specialization}</p>}
                        {item.website && (
                          <p>
                            Website:{" "}
                            {item.website.map((site, i) => (
                              <span key={i}>
                                <a href={`http://${site}`} target="_blank" rel="noopener noreferrer">
                                  {site}
                                </a>
                                {i < item.website.length - 1 ? ", " : ""}
                              </span>
                            ))}
                          </p>
                        )}
                        <Rating
                          rating={ratings[item.name]?.value || 0}
                          onRate={(value) => handleRate(item.name, value)}
                          numRatings={ratings[item.name]?.count || 0}
                          averageRating={getAverageRating(item.name)}
                        />
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
            
          </div>

          
        </>
      )}
      <div className="banner-section desktop">
              <h1>Banner-</h1>
            </div>
            <div className="banner-section mobile">
            <h1>banner</h1>
            </div>
    </>
    
  );
};

export default App;


