import React, { useState, useEffect } from 'react';
import axiosInstance from './axiosInstance.js';
import './AdminPanel.css';

const AdminPanel = () => {
  const [posts, setPosts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [newPost, setNewPost] = useState({
    cat_id: '',
    cat: '',
    data: [{ name: '', phone: '', address: '', website: '', priority: '' }]
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPost, setCurrentPost] = useState(null);
  const [currentDataItem, setCurrentDataItem] = useState(null);
  const [isAddingNewCategory, setIsAddingNewCategory] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    axiosInstance.get('/api/posts', { withCredentials: true })
      .then(response => {
        setPosts(response.data.data.posts);
        setCategories([...new Set(response.data.data.posts.map(post => post.cat))]);
      })
      .catch(error => {
        console.error('Error fetching posts:', error);
        if (error.response) {
          console.error('Response data:', error.response.data);
          console.error('Response status:', error.response.status);
          console.error('Response headers:', error.response.headers);
        } else if (error.request) {
          console.error('Request data:', error.request);
        } else {
          console.error('Error message:', error.message);
        }
        console.error('Error config:', error.config);
      });
  }, []);

  const handleDelete = (postId, itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      axiosInstance.delete(`/api/posts/${postId}`)
        .then(response => {
          setPosts(posts.map(post =>
            post._id === postId ? {
              ...post,
              data: post.data.filter(item => item._id !== itemId)
            } : post
          ));
          alert('Post deleted successfully.');
        })
        .catch(error => {
          console.error('There was an error deleting the post!', error);
          alert('There was an error deleting the post!');
        });
    }
  };

  const handleInputChange = (e, index = null) => {
    const { name, value } = e.target;

    if (index !== null) {
      setNewPost(prevState => {
        const newData = [...prevState.data];
        newData[index][name] = name === 'phone' || name === 'website' ? value.split(', ') : value;
        return {
          ...prevState,
          data: newData
        };
      });
    } else {
      setNewPost(prevState => ({
        ...prevState,
        [name]: value
      }));
    }
  };

  const handleCreate = (e) => {
    e.preventDefault();

    if (isAddingNewCategory && !newPost.cat) {
      alert('Please enter a new category.');
      return;
    }

    if (!isAddingNewCategory && !newPost.cat) {
      alert('Please select a category.');
      return;
    }

    const existingPost = posts.find(post => post.cat === newPost.cat);

    if (existingPost) {
      const updatedData = [...existingPost.data, ...newPost.data];
      axiosInstance.put(`/api/posts/${existingPost._id}`, { ...existingPost, data: updatedData })
        .then(response => {
          setPosts(posts.map(post => post._id === existingPost._id ? response.data.data.post : post));
          setNewPost({
            cat_id: '',
            cat: '',
            data: [{ name: '', phone: '', address: '', website: '', priority: '' }]
          });
          setIsAddingNewCategory(false);
          alert('User added to existing category successfully.');
        })
        .catch(error => {
          console.error('There was an error adding the user to the existing category!', error);
          alert('There was an error adding the user to the existing category!');
        });
    } else {
      axiosInstance.post('/api/posts', newPost)
        .then(response => {
          setPosts([...posts, response.data.data.post]);
          setNewPost({
            cat_id: '',
            cat: '',
            data: [{ name: '', phone: '', address: '', website: '', priority: '' }]
          });
          setIsAddingNewCategory(false);
          alert('Post created successfully.');
        })
        .catch(error => {
          console.error('There was an error creating the post!', error);
          alert('There was an error creating the post!');
        });
    }
  };

  const handleEdit = (post, dataItem) => {
    setCurrentPost(post);
    setCurrentDataItem(dataItem);
    setIsModalOpen(true);
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    const updatedData = currentPost.data.map(item =>
      item._id === currentDataItem._id ? currentDataItem : item
    );
    axiosInstance.put(`/api/posts/${currentPost._id}`, { ...currentPost, data: updatedData })
      .then(response => {
        setPosts(posts.map(post => (post._id === currentPost._id ? response.data.data.post : post)));
        setIsModalOpen(false);
        setCurrentPost(null);
        setCurrentDataItem(null);
        alert('Post updated successfully.');
      })
      .catch(error => {
        console.error('There was an error updating the post!', error);
        alert('There was an error updating the post!');
      });
  };

  const renderData = (post) => {
    return post.data.map((item, index) => (
      <div className="data-container" key={item._id}>
        <p>Name: {item.name}</p>
        <p>Phone: {Array.isArray(item.phone) ? item.phone.join(', ') : item.phone}</p>
        <p>Address: {item.address}</p>
        <p>Website: {Array.isArray(item.website) ? item.website.join(', ') : item.website}</p>
        <p>Priority: {item.priority}</p>
        <button onClick={() => handleDelete(post._id, item._id)}>Delete</button>
        <button onClick={() => handleEdit(post, item)}>Edit</button>
      </div>
    ));
  };

  const filteredPosts = posts.filter(post =>
    post.cat.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.data.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div>
      <h1>Admin Panel</h1>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search by category or item name"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="form-container">
        <h2>Create New User</h2>
        <form onSubmit={handleCreate}>
          <select
            name="cat"
            value={isAddingNewCategory ? "" : newPost.cat}
            onChange={(e) => {
              const value = e.target.value;
              if (value === "new") {
                setIsAddingNewCategory(true);
                setNewPost({ ...newPost, cat: "" });
              } else {
                setIsAddingNewCategory(false);
                setNewPost({ ...newPost, cat: value });
              }
            }}
            required
          >
            <option value="">Select Category</option>
            <option value="new">Add New Category</option>
            {categories.map((category, index) => (
              <option key={index} value={category}>
                {category}
              </option>
            ))}
          </select>
          {isAddingNewCategory && (
            <input
              type="text"
              name="cat"
              placeholder="New Category"
              value={newPost.cat}
              onChange={handleInputChange}
              required
            />
          )}
          {newPost.data.map((item, index) => (
            <div key={index}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={item.name}
                onChange={(e) => handleInputChange(e, index)}
                required
              />
              <input
                type="text"
                name="phone"
                placeholder="Phone"
                value={Array.isArray(item.phone) ? item.phone.join(', ') : item.phone}
                onChange={(e) => handleInputChange(e, index)}
                required
              />
              <input
                type="text"
                name="address"
                placeholder="Address"
                value={item.address}
                onChange={(e) => handleInputChange(e, index)}
                required
              />
              <input
                type="text"
                name="website"
                placeholder="Website"
                value={Array.isArray(item.website) ? item.website.join(', ') : item.website}
                onChange={(e) => handleInputChange(e, index)}
              />
              <input
                type="number"
                name="priority"
                placeholder="Priority"
                value={item.priority}
                onChange={(e) => handleInputChange(e, index)}
                required
              />
            </div>
          ))}
          <button type="submit">Create</button>
        </form>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Category</th>
              <th>Data</th>
            </tr>
          </thead>
          <tbody>
            {filteredPosts.map(post => (
              <tr key={post._id}>
                <td>{post.cat}</td>
                <td>{renderData(post)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setIsModalOpen(false)}>&times;</span>
            <h2>Edit Data Item</h2>
            <form onSubmit={handleUpdate}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={currentDataItem.name}
                onChange={e => setCurrentDataItem({ ...currentDataItem, name: e.target.value })}
                required
              />
              <input
                type="text"
                name="phone"
                placeholder="Phone"
                value={Array.isArray(currentDataItem.phone) ? currentDataItem.phone.join(', ') : currentDataItem.phone}
                onChange={e => setCurrentDataItem({ ...currentDataItem, phone: e.target.value.split(', ') })}
              />
              <input
                type="text"
                name="address"
                placeholder="Address"
                value={currentDataItem.address}
                onChange={e => setCurrentDataItem({ ...currentDataItem, address: e.target.value })}
              />
              <input
                type="text"
                name="website"
                placeholder="Website"
                value={Array.isArray(currentDataItem.website) ? currentDataItem.website.join(', ') : currentDataItem.website}
                onChange={e => setCurrentDataItem({ ...currentDataItem, website: e.target.value.split(', ') })}
              />
              <input
                type="number"
                name="priority"
                placeholder="Priority"
                value={currentDataItem.priority}
                onChange={e => setCurrentDataItem({ ...currentDataItem, priority: e.target.value })}
              />
              <button type="submit">Update</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
