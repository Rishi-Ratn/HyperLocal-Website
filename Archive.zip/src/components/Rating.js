import React, { useState } from 'react';
import axios from 'axios';

const Rating = ({ rating, onRate, numRatings, averageRating }) => {
  const [hover, setHover] = useState(0);

  const handleRate = (newRating) => {
    onRate(newRating);
    axios.post('http://localhost:5002/api/ratings', { itemId: 'item1', userEmail: 'user@example.com', rating: newRating })
      .then(response => {
        console.log('Rating updated:', response.data);
      })
      .catch(error => {
        console.error('Error updating rating:', error);
      });
  };

  return (
    <div>
      <div className="star-rating">
        {[...Array(5)].map((star, index) => {
          index += 1;
          return (
            <button
              type="button"
              key={index}
              className={index <= (hover || rating) ? "on" : "off"}
              onClick={() => handleRate(index)}
              onMouseEnter={() => setHover(index)}
              onMouseLeave={() => setHover(rating)}
            >
              <span className="star">&#9733;</span>
            </button>
          );
        })}
      </div>
      <div>
        <p>Average Rating: {averageRating ? averageRating.toFixed(2) : "N/A"}</p>
        <p>Number of Ratings: {numRatings}</p>
      </div>
    </div>
  );
};

export default Rating;
